import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Vite configuration for the Traveller Declaration app. In development, we
// configure a proxy so that calls to `/dhis2` are forwarded to the remote
// DHIS2 server. This proxy is necessary because the DHIS2 API does not allow
// cross‑origin requests from localhost. See README for details.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // Proxy API calls starting with `/dhis2` to the DHIS2 server. The
      // `rewrite` function strips off the `/dhis2` prefix and prepends `/api`
      // because API_PREFIX uses `/dhis2` for convenience and the actual
      // endpoints live under `/api` on the DHIS2 server.
      '/dhis2': {
        target: 'https://staging.ephi.gov.et',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/dhis2/, '/api'),
      },
    },
  },
});
