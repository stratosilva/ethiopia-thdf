// PostCSS configuration for an ES module environment. Because the package.json
// specifies "type": "module", CommonJS globals like `module` and `require` are
// not available. We use ESM imports instead. If you install
// `@tailwindcss/postcss`, you can import it here; otherwise fall back to the
// built-in tailwindcss plugin (which works in Tailwind v4+).
// Import the Tailwind CSS plugin for PostCSS. In Tailwind v4, the PostCSS
// plugin is provided by the `@tailwindcss/postcss` package. If this package
// is not installed, you will need to run `npm install --save-dev @tailwindcss/postcss`.
import tailwindcss from '@tailwindcss/postcss';
import autoprefixer from 'autoprefixer';

export default {
  // Use object syntax for PostCSS plugins. Each key is the plugin imported above.
  plugins: {
    tailwindcss,
    autoprefixer,
  },
};
